import { Component, OnInit, ComponentFactoryResolver } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers-component.component.html',
  styleUrls: ['./servers-component.component.css']
})
export class ServersComponentComponent implements OnInit {
    isAllowed=false;
    servercheck="Server is not Created Yet";
    servername='TestServer';
    serverCreate=false;
    servers=['Test Server', 'Test Server2'];
  constructor() { 
    setTimeout(() => {
      this.isAllowed=true;
    }, 2000);
  }

  ngOnInit() {
  }

  onServerClick(){
    this.serverCreate=true;
    this.servers.push(this.servername);
    this.servercheck="server is created Now, Server Name is: "+ this.servername;
  }

  onServerButton(){
    this.serverCreate=true;
    this.servers.push(this.servername);
    this.servercheck="server is created Now, Server Name is: "+ this.servername;
  }

  onServerChange(event: any){
    this.servername=event.target.value;
  }

}
